const pool = require('../config/db');

module.exports = {
  getCartByUserId: async (userId) => {
    const [rows] = await pool.query(`
      SELECT ci.*, mi.name, mi.price, mi.image_url as image 
      FROM cart_items ci
      JOIN menu_items mi ON ci.menu_item_id = mi.id
      WHERE ci.cart_id = (
        SELECT id FROM carts WHERE user_id = ? LIMIT 1
      )
    `, [userId]);
    return rows;
  },

  getCartTotal: async (userId) => {
    const [rows] = await pool.query(`
      SELECT SUM(mi.price * ci.quantity) as total
      FROM cart_items ci
      JOIN menu_items mi ON ci.menu_item_id = mi.id
      WHERE ci.cart_id = (
        SELECT id FROM carts WHERE user_id = ? LIMIT 1
      )
    `, [userId]);
    return rows[0].total || 0;
  },

  addToCart: async (userId, itemId, quantity) => {
    await pool.query('INSERT INTO carts (user_id) VALUES (?) ON DUPLICATE KEY UPDATE user_id = user_id', [userId]);
    
    const [existing] = await pool.query(`
      SELECT * FROM cart_items 
      WHERE cart_id = (SELECT id FROM carts WHERE user_id = ?) 
      AND menu_item_id = ?
    `, [userId, itemId]);

    if (existing.length > 0) {
      await pool.query(`
        UPDATE cart_items 
        SET quantity = quantity + ? 
        WHERE id = ?
      `, [quantity, existing[0].id]);
    } else {
      await pool.query(`
        INSERT INTO cart_items (cart_id, menu_item_id, quantity)
        VALUES (
          (SELECT id FROM carts WHERE user_id = ?), 
          ?, ?
        )
      `, [userId, itemId, quantity]);
    }

    return this.getCartByUserId(userId);
  },

  updateCartItem: async (userId, itemId, quantity) => {
    await pool.query(`
      UPDATE cart_items 
      SET quantity = ? 
      WHERE cart_id = (SELECT id FROM carts WHERE user_id = ?) 
      AND menu_item_id = ?
    `, [quantity, userId, itemId]);

    return this.getCartByUserId(userId);
  },

  removeFromCart: async (userId, itemId) => {
    await pool.query(`
      DELETE FROM cart_items 
      WHERE cart_id = (SELECT id FROM carts WHERE user_id = ?) 
      AND menu_item_id = ?
    `, [userId, itemId]);

    return this.getCartByUserId(userId);
  },

  clearCart: async (userId) => {
    await pool.query(`
      DELETE FROM cart_items 
      WHERE cart_id = (SELECT id FROM carts WHERE user_id = ?)
    `, [userId]);
  }
};