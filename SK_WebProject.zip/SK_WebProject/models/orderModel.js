const pool = require('../config/db');

module.exports = {
  createOrder: async (userId) => {
    const conn = await pool.getConnection();
    await conn.beginTransaction();

    try {
      // Get cart items
      const [cartItems] = await conn.query(`
        SELECT ci.menu_item_id, ci.quantity, mi.price 
        FROM cart_items ci
        JOIN menu_items mi ON ci.menu_item_id = mi.id
        WHERE ci.cart_id = (SELECT id FROM carts WHERE user_id = ?)
      `, [userId]);

      if (cartItems.length === 0) {
        throw new Error('Keranjang belanja kosong');
      }

      // Calculate total
      const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

      // Create order
      const [orderResult] = await conn.query(`
        INSERT INTO orders (user_id, total_amount, status)
        VALUES (?, ?, 'Diproses')
      `, [userId, total]);
      const orderId = orderResult.insertId;

      // Add order items
      for (const item of cartItems) {
        await conn.query(`
          INSERT INTO order_items (order_id, menu_item_id, quantity, price)
          VALUES (?, ?, ?, ?)
        `, [orderId, item.menu_item_id, item.quantity, item.price]);
      }

      // Clear cart
      await conn.query(`
        DELETE FROM cart_items 
        WHERE cart_id = (SELECT id FROM carts WHERE user_id = ?)
      `, [userId]);

      await conn.commit();

      return {
        id: orderId,
        total,
        items: cartItems
      };
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      conn.release();
    }
  },

  getOrderHistory: async (userId) => {
    const [orders] = await pool.query(`
      SELECT o.* FROM orders o
      WHERE o.user_id = ?
      ORDER BY o.order_date DESC
    `, [userId]);

    return orders;
  },

  getOrderDetails: async (orderId) => {
    const [order] = await pool.query('SELECT * FROM orders WHERE id = ?', [orderId]);
    const [items] = await pool.query(`
      SELECT oi.*, mi.name, mi.image_url as image
      FROM order_items oi
      JOIN menu_items mi ON oi.menu_item_id = mi.id
      WHERE oi.order_id = ?
    `, [orderId]);

    return {
      ...order[0],
      items
    };
  }
};