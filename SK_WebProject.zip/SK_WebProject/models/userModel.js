const pool = require('../config/db');

module.exports = {
  registerUser: async (userData) => {
    const [result] = await pool.query(
      'INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)',
      [userData.name, userData.email, userData.phone, userData.password]
    );
    return result.insertId;
  },

  findUserByEmail: async (email) => {
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    return rows[0];
  },

  getUserById: async (id) => {
    const [rows] = await pool.query('SELECT id, name, email, phone FROM users WHERE id = ?', [id]);
    return rows[0];
  }
};