const pool = require('../config/db');

module.exports = {
  getAllMenuItems: async () => {
    const [rows] = await pool.query(`
      SELECT m.*, c.name as category_name 
      FROM menu_items m
      JOIN categories c ON m.category_id = c.id
    `);
    return rows;
  },

  getMenuItemsByCategory: async (categoryId) => {
    const [rows] = await pool.query('SELECT * FROM menu_items WHERE category_id = ?', [categoryId]);
    return rows;
  },

  getMenuItemById: async (id) => {
    const [rows] = await pool.query('SELECT * FROM menu_items WHERE id = ?', [id]);
    return rows[0];
  }
};