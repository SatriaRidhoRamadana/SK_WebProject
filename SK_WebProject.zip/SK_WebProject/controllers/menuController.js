const menuModel = require('../models/menuModel');

module.exports = {
  getAllMenuItems: async (req, res) => {
    try {
      const menuItems = await menuModel.getAllMenuItems();
      res.json(menuItems);
    } catch (error) {
      res.status(500).json({ message: 'Gagal mengambil menu', error: error.message });
    }
  },

  getMenuItemsByCategory: async (req, res) => {
    try {
      const menuItems = await menuModel.getMenuItemsByCategory(req.params.id);
      res.json(menuItems);
    } catch (error) {
      res.status(500).json({ message: 'Gagal mengambil menu berdasarkan kategori', error: error.message });
    }
  },

  getMenuItemById: async (req, res) => {
    try {
      const menuItem = await menuModel.getMenuItemById(req.params.id);
      
      if (!menuItem) {
        return res.status(404).json({ message: 'Menu tidak ditemukan' });
      }

      res.json(menuItem);
    } catch (error) {
      res.status(500).json({ message: 'Gagal mengambil detail menu', error: error.message });
    }
  }
};