const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const userModel = require('../models/userModel');
require('dotenv').config();

module.exports = {
  register: async (req, res) => {
    try {
      const { name, email, phone, password, confirmPassword } = req.body;
      
      if (password !== confirmPassword) {
        return res.status(400).json({ message: 'Password tidak cocok!' });
      }

      const existingUser = await userModel.findUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: 'Email sudah terdaftar!' });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const userId = await userModel.registerUser({
        name, email, phone, password: hashedPassword
      });

      const user = await userModel.getUserById(userId);
      const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

      res.status(201).json({ 
        message: 'Pendaftaran berhasil!', 
        user, 
        token 
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  },

  login: async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await userModel.findUserByEmail(email);

      if (!user) {
        return res.status(400).json({ message: 'Email atau password salah!' });
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(400).json({ message: 'Email atau password salah!' });
      }

      const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
      const userData = await userModel.getUserById(user.id);

      res.json({ 
        message: 'Login berhasil!', 
        user: userData, 
        token 
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  },

  getProfile: async (req, res) => {
    try {
      const user = await userModel.getUserById(req.user.id);
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  }
};