const cartModel = require('../models/cartModel');

module.exports = {
  getCart: async (req, res) => {
    try {
      const items = await cartModel.getCartByUserId(req.user.id);
      const total = await cartModel.getCartTotal(req.user.id);
      
      res.json({
        items,
        total
      });
    } catch (error) {
      res.status(500).json({ message: 'Gagal mengambil keranjang', error: error.message });
    }
  },

  addToCart: async (req, res) => {
    try {
      const { itemId, quantity = 1 } = req.body;
      await cartModel.addToCart(req.user.id, itemId, quantity);
      
      const items = await cartModel.getCartByUserId(req.user.id);
      const total = await cartModel.getCartTotal(req.user.id);
      
      res.json({
        message: 'Item berhasil ditambahkan ke keranjang',
        items,
        total
      });
    } catch (error) {
      res.status(500).json({ message: 'Gagal menambahkan ke keranjang', error: error.message });
    }
  },

  updateCartItem: async (req, res) => {
    try {
      const { itemId } = req.params;
      const { quantity } = req.body;
      
      if (quantity < 1) {
        return res.status(400).json({ message: 'Jumlah tidak valid' });
      }

      await cartModel.updateCartItem(req.user.id, itemId, quantity);
      
      const items = await cartModel.getCartByUserId(req.user.id);
      const total = await cartModel.getCartTotal(req.user.id);
      
      res.json({
        message: 'Keranjang berhasil diupdate',
        items,
        total
      });
    } catch (error) {
      res.status(500).json({ message: 'Gagal mengupdate keranjang', error: error.message });
    }
  },

  removeFromCart: async (req, res) => {
    try {
      const { itemId } = req.params;
      await cartModel.removeFromCart(req.user.id, itemId);
      
      const items = await cartModel.getCartByUserId(req.user.id);
      const total = await cartModel.getCartTotal(req.user.id);
      
      res.json({
        message: 'Item berhasil dihapus dari keranjang',
        items,
        total
      });
    } catch (error) {
      res.status(500).json({ message: 'Gagal menghapus dari keranjang', error: error.message });
    }
  }
};