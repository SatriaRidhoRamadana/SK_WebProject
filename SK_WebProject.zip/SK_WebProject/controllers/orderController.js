const orderModel = require('../models/orderModel');

module.exports = {
  checkout: async (req, res) => {
    try {
      const order = await orderModel.createOrder(req.user.id);
      res.json({
        message: 'Pesanan berhasil dibuat',
        order
      });
    } catch (error) {
      res.status(500).json({ message: 'Checkout gagal', error: error.message });
    }
  },

  getOrderHistory: async (req, res) => {
    try {
      const orders = await orderModel.getOrderHistory(req.user.id);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: 'Gagal mengambil riwayat pesanan', error: error.message });
    }
  },

  getOrderDetails: async (req, res) => {
    try {
      const order = await orderModel.getOrderDetails(req.params.id);
      
      if (!order) {
        return res.status(404).json({ message: 'Pesanan tidak ditemukan' });
      }

      if (order.user_id !== req.user.id) {
        return res.status(403).json({ message: 'Anda tidak memiliki akses ke pesanan ini' });
      }

      res.json(order);
    } catch (error) {
      res.status(500).json({ message: 'Gagal mengambil detail pesanan', error: error.message });
    }
  }
};