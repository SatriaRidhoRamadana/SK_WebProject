const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');

router.post('/', orderController.checkout);
router.get('/', orderController.getOrderHistory);
router.get('/:id', orderController.getOrderDetails);

module.exports = router;