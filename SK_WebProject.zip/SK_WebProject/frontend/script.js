import { authService } from './services/authService.js';
import { cartService } from './services/cartService.js';
import { menuService } from './services/menuService.js';

document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const authModal = document.getElementById('authModal');
    const cartModal = document.getElementById('cartModal');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const showRegister = document.getElementById('showRegister');
    const showLogin = document.getElementById('showLogin');
    const cartIcon = document.querySelector('.cart-icon');
    const closeModals = document.querySelectorAll('.close-modal');
    const loginBtn = document.querySelector('.btn-login');
    const menuItemsContainer = document.querySelector('.menu-items');
    const addToCartBtns = document.querySelectorAll('.btn-add');
    const cartItemsContainer = document.querySelector('.cart-items');
    const cartTotal = document.querySelector('.total-price');
    const checkoutBtn = document.getElementById('checkoutBtn');
    const emptyCartMsg = document.querySelector('.empty-cart');
    const cartCount = document.querySelector('.cart-count');
    const filterBtns = document.querySelectorAll('.filter-btn');

    // State
    let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;
    let cart = [];
    let menuItems = [];

    // Initialize
    loadMenuItems();
    updateCartUI();
    updateUserUI();

    // Event Listeners
    loginBtn.addEventListener('click', openAuthModal);
    cartIcon.addEventListener('click', openCartModal);
    showRegister.addEventListener('click', showRegisterForm);
    showLogin.addEventListener('click', showLoginForm);
    checkoutBtn.addEventListener('click', checkout);

    closeModals.forEach(btn => {
        btn.addEventListener('click', closeModal);
    });

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === authModal) {
            closeModal();
        }
        if (event.target === cartModal) {
            closeModal();
        }
    });

    // Login Form Submission
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        
        try {
            const { user, token } = await authService.login({ email, password });
            currentUser = user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            localStorage.setItem('token', token);
            
            updateUserUI();
            closeModal();
            showAlert('Login berhasil!', 'success');
        } catch (error) {
            showAlert(error.message || 'Email atau password salah!', 'error');
        }
    });

    // Register Form Submission
    registerForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const name = document.getElementById('registerName').value;
        const email = document.getElementById('registerEmail').value;
        const phone = document.getElementById('registerPhone').value;
        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('registerConfirmPassword').value;
        
        try {
            const { user, token } = await authService.register({ 
                name, 
                email, 
                phone, 
                password, 
                confirmPassword 
            });
            
            currentUser = user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            localStorage.setItem('token', token);
            
            updateUserUI();
            showLoginForm();
            showAlert('Pendaftaran berhasil! Anda sudah login.', 'success');
        } catch (error) {
            showAlert(error.message || 'Pendaftaran gagal', 'error');
        }
    });

    // Filter buttons
    filterBtns.forEach(btn => {
        btn.addEventListener('click', async function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const category = this.textContent.toLowerCase();
            
            try {
                if (category === 'semua') {
                    menuItems = await menuService.getAllMenuItems();
                } else {
                    const categoryMap = { makanan: 1, minuman: 2, snack: 3 };
                    menuItems = await menuService.getMenuByCategory(categoryMap[category]);
                }
                
                renderMenuItems(menuItems);
            } catch (error) {
                showAlert(error.message || 'Gagal memuat menu', 'error');
            }
        });
    });

    // Functions
    async function loadMenuItems() {
        try {
            menuItems = await menuService.getAllMenuItems();
            renderMenuItems(menuItems);
        } catch (error) {
            showAlert(error.message || 'Gagal memuat menu', 'error');
        }
    }

    function renderMenuItems(items) {
        menuItemsContainer.innerHTML = '';
        
        items.forEach(item => {
            const menuItem = document.createElement('div');
            menuItem.className = 'menu-item';
            menuItem.dataset.category = item.category_name.toLowerCase();
            menuItem.innerHTML = `
                <img src="${item.image_url}" alt="${item.name}">
                <div class="menu-details">
                    <h3>${item.name}</h3>
                    <p>${item.description}</p>
                    <div class="price">Rp ${item.price.toLocaleString('id-ID')}</div>
                    <button class="btn-add" data-id="${item.id}">+ Tambah</button>
                </div>
            `;
            
            menuItemsContainer.appendChild(menuItem);
            
            menuItem.querySelector('.btn-add').addEventListener('click', function() {
                addToCart({
                    id: item.id,
                    name: item.name,
                    price: item.price,
                    image: item.image_url,
                    quantity: 1
                });
            });
        });
    }

    function openAuthModal() {
        if (currentUser) {
            logout();
            return;
        }
        authModal.style.display = 'block';
        setTimeout(() => {
            authModal.classList.add('show');
        }, 10);
    }

    async function openCartModal() {
        if (!currentUser) {
            openAuthModal();
            return;
        }
        
        try {
            await renderCartItems();
            cartModal.style.display = 'block';
            setTimeout(() => {
                cartModal.classList.add('show');
            }, 10);
        } catch (error) {
            showAlert(error.message || 'Gagal memuat keranjang', 'error');
        }
    }

    function closeModal() {
        authModal.classList.remove('show');
        cartModal.classList.remove('show');
        setTimeout(() => {
            authModal.style.display = 'none';
            cartModal.style.display = 'none';
        }, 300);
    }

    function showRegisterForm(e) {
        e.preventDefault();
        document.getElementById('loginForm').classList.remove('active');
        document.getElementById('registerForm').classList.add('active');
    }

    function showLoginForm(e) {
        if (e) e.preventDefault();
        document.getElementById('registerForm').classList.remove('active');
        document.getElementById('loginForm').classList.add('active');
    }

    async function addToCart(item) {
        if (!currentUser) {
            openAuthModal();
            return;
        }

        try {
            await cartService.addToCart(item.id, item.quantity);
            updateCartUI();
            showAlert(`${item.name} ditambahkan ke keranjang!`, 'success');
        } catch (error) {
            showAlert(error.message || 'Gagal menambahkan ke keranjang', 'error');
        }
    }

    async function updateCartUI() {
        if (!currentUser) {
            cartCount.style.display = 'none';
            return;
        }

        try {
            const { items } = await cartService.getCart();
            cart = items;
            const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
            cartCount.textContent = totalItems;
            
            if (totalItems > 0) {
                cartCount.style.display = 'flex';
            } else {
                cartCount.style.display = 'none';
            }
        } catch (error) {
            console.error('Gagal memperbarui UI keranjang:', error);
        }
    }

    async function renderCartItems() {
        try {
            const { items, total } = await cartService.getCart();
            cart = items;
            
            if (cart.length === 0) {
                emptyCartMsg.style.display = 'block';
                cartItemsContainer.innerHTML = '<p class="empty-cart">Keranjang belanja kosong</p>';
                checkoutBtn.disabled = true;
                cartTotal.textContent = 'Rp 0';
                return;
            }
            
            emptyCartMsg.style.display = 'none';
            cartItemsContainer.innerHTML = '';
            
            cart.forEach(item => {
                const itemElement = document.createElement('div');
                itemElement.className = 'cart-item';
                itemElement.innerHTML = `
                    <img src="${item.image}" alt="${item.name}" width="60" height="60">
                    <div class="cart-item-info">
                        <div class="cart-item-name">${item.name}</div>
                        <div class="cart-item-price">Rp ${item.price.toLocaleString('id-ID')}</div>
                    </div>
                    <div class="cart-item-quantity">
                        <button class="quantity-btn minus" data-id="${item.id}">-</button>
                        <span>${item.quantity}</span>
                        <button class="quantity-btn plus" data-id="${item.id}">+</button>
                    </div>
                    <button class="cart-item-remove" data-id="${item.id}">&times;</button>
                `;
                
                cartItemsContainer.appendChild(itemElement);
                
                itemElement.querySelector('.minus').addEventListener('click', async function() {
                    await updateQuantity(item.id, -1);
                });
                
                itemElement.querySelector('.plus').addEventListener('click', async function() {
                    await updateQuantity(item.id, 1);
                });
                
                itemElement.querySelector('.cart-item-remove').addEventListener('click', async function() {
                    await removeItem(item.id);
                });
            });
            
            cartTotal.textContent = `Rp ${total.toLocaleString('id-ID')}`;
            checkoutBtn.disabled = false;
        } catch (error) {
            throw error;
        }
    }

    async function updateQuantity(id, change) {
        try {
            const item = cart.find(item => item.id === id);
            const newQuantity = item.quantity + change;
            
            if (newQuantity <= 0) {
                await cartService.removeFromCart(id);
            } else {
                await cartService.updateCartItem(id, newQuantity);
            }
            
            await updateCartUI();
            await renderCartItems();
        } catch (error) {
            showAlert(error.message || 'Gagal mengupdate jumlah', 'error');
        }
    }

    async function removeItem(id) {
        try {
            await cartService.removeFromCart(id);
            await updateCartUI();
            await renderCartItems();
            showAlert('Item dihapus dari keranjang', 'info');
        } catch (error) {
            showAlert(error.message || 'Gagal menghapus item', 'error');
        }
    }

    async function checkout() {
        if (cart.length === 0) return;
        
        try {
            const order = await cartService.checkout();
            showAlert(`Pesanan sebesar ${order.total} berhasil diproses! Terima kasih.`, 'success');
            await updateCartUI();
            await renderCartItems();
            closeModal();
        } catch (error) {
            showAlert(error.message || 'Checkout gagal', 'error');
        }
    }

    async function updateUserUI() {
        if (currentUser) {
            try {
                // Ambil data terbaru dari server
                const user = await authService.getProfile();
                currentUser = user;
                localStorage.setItem('currentUser', JSON.stringify(currentUser));
                
                loginBtn.innerHTML = `
                    <div class="user-info">
                        <div class="user-avatar">${user.name.charAt(0).toUpperCase()}</div>
                        <span class="user-name">${user.name.split(' ')[0]}</span>
                        <div class="user-dropdown">
                            <a href="#"><i class="fas fa-user"></i> Profil</a>
                            <a href="#"><i class="fas fa-history"></i> Riwayat</a>
                            <a href="#" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                `;
                
                document.getElementById('logoutBtn').addEventListener('click', function(e) {
                    e.preventDefault();
                    logout();
                });
            } catch (error) {
                console.error('Gagal memuat data pengguna:', error);
                logout();
            }
        } else {
            loginBtn.textContent = 'Login';
            loginBtn.classList.add('btn-login');
        }
    }

    function logout() {
        authService.logout();
        currentUser = null;
        cart = [];
        localStorage.removeItem('currentUser');
        localStorage.removeItem('token');
        updateUserUI();
        updateCartUI();
        showAlert('Anda telah logout', 'info');
    }

    function showAlert(message, type) {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.textContent = message;
        document.body.appendChild(alert);
        
        setTimeout(() => {
            alert.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            alert.classList.remove('show');
            setTimeout(() => {
                alert.remove();
            }, 300);
        }, 3000);
    }

    // Scroll to top button functionality
    const scrollTopBtn = document.createElement('div');
    scrollTopBtn.className = 'scroll-top';
    scrollTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    document.body.appendChild(scrollTopBtn);
    
    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            scrollTopBtn.classList.add('active');
        } else {
            scrollTopBtn.classList.remove('active');
        }
    });

    // Error handling global
    window.addEventListener('unhandledrejection', (event) => {
        console.error('Unhandled promise rejection:', event.reason);
        showAlert('Terjadi kesalahan pada sistem', 'error');
    });
});